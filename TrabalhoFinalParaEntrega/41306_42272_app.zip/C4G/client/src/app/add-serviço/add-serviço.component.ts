import { Component, Injector } from '@angular/core';
import { AddServicoGenerated } from './add-serviço-generated.component';

@Component({
  selector: 'page-add-serviço',
  templateUrl: './add-serviço.component.html'
})
export class AddServicoComponent extends AddServicoGenerated {
  constructor(injector: Injector) {
    super(injector);
  }
}
