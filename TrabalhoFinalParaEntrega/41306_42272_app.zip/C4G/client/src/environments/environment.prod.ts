export const environment = {
  serverMethodsUrl: 'http://localhost:5000/',
  c4G: 'http://localhost:5000/odata/C4G',

  securityUrl: 'http://localhost:5000/auth',
  production: true
};
