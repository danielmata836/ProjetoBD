﻿using System;
using System.Text;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Tokens;

namespace C4G.Authentication
{
    public class TokenProviderOptions
    {
        public static string Audience { get; } = "C4GAudience";
        public static string Issuer { get; } = "C4G";
        public static SymmetricSecurityKey Key { get; } = new SymmetricSecurityKey(Encoding.ASCII.GetBytes("C4GSecretSecurityKeyC4G"));
        public static TimeSpan Expiration { get; } = TimeSpan.FromMinutes(30);
        public static SigningCredentials SigningCredentials { get; } = new SigningCredentials(Key, SecurityAlgorithms.HmacSha256);
    }
}
