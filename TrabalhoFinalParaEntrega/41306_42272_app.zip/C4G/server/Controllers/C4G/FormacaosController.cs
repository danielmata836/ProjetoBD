using System;
using System.Net;
using System.Data;
using System.Linq;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNet.OData;
using Microsoft.AspNet.OData.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.AspNet.OData.Query;



namespace C4G.Controllers.C4G
{
  using Models;
  using Data;
  using Models.C4G;

  [ODataRoutePrefix("odata/C4G/Formacaos")]
  [Route("mvc/odata/C4G/Formacaos")]
  public partial class FormacaosController : ODataController
  {
    private Data.C4GContext context;

    public FormacaosController(Data.C4GContext context)
    {
      this.context = context;
    }
    // GET /odata/C4G/Formacaos
    [EnableQuery(MaxExpansionDepth=10,MaxAnyAllExpressionDepth=10,MaxNodeCount=1000)]
    [HttpGet]
    public IEnumerable<Models.C4G.Formacao> GetFormacaos()
    {
      var items = this.context.Formacaos.AsQueryable<Models.C4G.Formacao>();
      this.OnFormacaosRead(ref items);

      return items;
    }

    partial void OnFormacaosRead(ref IQueryable<Models.C4G.Formacao> items);

    [EnableQuery(MaxExpansionDepth=10,MaxAnyAllExpressionDepth=10,MaxNodeCount=1000)]
    [HttpGet("{index_formacao}")]
    public SingleResult<Formacao> GetFormacao(int key)
    {
        var items = this.context.Formacaos.Where(i=>i.index_formacao == key);
        this.OnFormacaosGet(ref items);

        return SingleResult.Create(items);
    }

    partial void OnFormacaosGet(ref IQueryable<Models.C4G.Formacao> items);

    partial void OnFormacaoDeleted(Models.C4G.Formacao item);

    [HttpDelete("{index_formacao}")]
    public IActionResult DeleteFormacao(int key)
    {
        try
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }


            var item = this.context.Formacaos
                .Where(i => i.index_formacao == key)
                .FirstOrDefault();

            if (item == null)
            {
                ModelState.AddModelError("", "Item no longer available");
                return BadRequest(ModelState);
            }

            this.OnFormacaoDeleted(item);
            this.context.Formacaos.Remove(item);
            this.context.SaveChanges();

            return new NoContentResult();
        }
        catch(Exception ex)
        {
            ModelState.AddModelError("", ex.Message);
            return BadRequest(ModelState);
        }
    }

    partial void OnFormacaoUpdated(Models.C4G.Formacao item);

    [HttpPut("{index_formacao}")]
    [EnableQuery(MaxExpansionDepth=10,MaxAnyAllExpressionDepth=10,MaxNodeCount=1000)]
    public IActionResult PutFormacao(int key, [FromBody]Models.C4G.Formacao newItem)
    {
        try
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (newItem == null || (newItem.index_formacao != key))
            {
                return BadRequest();
            }

            this.OnFormacaoUpdated(newItem);
            this.context.Formacaos.Update(newItem);
            this.context.SaveChanges();

            var itemToReturn = this.context.Formacaos.Where(i => i.index_formacao == key);
            Request.QueryString = Request.QueryString.Add("$expand", "Recurso");
            return new ObjectResult(SingleResult.Create(itemToReturn));
        }
        catch(Exception ex)
        {
            ModelState.AddModelError("", ex.Message);
            return BadRequest(ModelState);
        }
    }

    [HttpPatch("{index_formacao}")]
    [EnableQuery(MaxExpansionDepth=10,MaxAnyAllExpressionDepth=10,MaxNodeCount=1000)]
    public IActionResult PatchFormacao(int key, [FromBody]Delta<Models.C4G.Formacao> patch)
    {
        try
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var item = this.context.Formacaos.Where(i => i.index_formacao == key).FirstOrDefault();

            if (item == null)
            {
                ModelState.AddModelError("", "Item no longer available");
                return BadRequest(ModelState);
            }

            patch.Patch(item);

            this.OnFormacaoUpdated(item);
            this.context.Formacaos.Update(item);
            this.context.SaveChanges();

            var itemToReturn = this.context.Formacaos.Where(i => i.index_formacao == key);
            Request.QueryString = Request.QueryString.Add("$expand", "Recurso");
            return new ObjectResult(SingleResult.Create(itemToReturn));
        }
        catch(Exception ex)
        {
            ModelState.AddModelError("", ex.Message);
            return BadRequest(ModelState);
        }
    }

    partial void OnFormacaoCreated(Models.C4G.Formacao item);

    [HttpPost]
    [EnableQuery(MaxExpansionDepth=10,MaxAnyAllExpressionDepth=10,MaxNodeCount=1000)]
    public IActionResult Post([FromBody] Models.C4G.Formacao item)
    {
        try
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (item == null)
            {
                return BadRequest();
            }

            this.OnFormacaoCreated(item);
            this.context.Formacaos.Add(item);
            this.context.SaveChanges();

            var key = item.index_formacao;

            var itemToReturn = this.context.Formacaos.Where(i => i.index_formacao == key);

            Request.QueryString = Request.QueryString.Add("$expand", "Recurso");

            return new ObjectResult(SingleResult.Create(itemToReturn))
            {
                StatusCode = 201
            };
        }
        catch(Exception ex)
        {
            ModelState.AddModelError("", ex.Message);
            return BadRequest(ModelState);
        }
    }
  }
}
