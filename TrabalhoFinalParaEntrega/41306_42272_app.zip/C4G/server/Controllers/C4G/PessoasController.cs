using System;
using System.Net;
using System.Data;
using System.Linq;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNet.OData;
using Microsoft.AspNet.OData.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.AspNet.OData.Query;



namespace C4G.Controllers.C4G
{
  using Models;
  using Data;
  using Models.C4G;

  [ODataRoutePrefix("odata/C4G/Pessoas")]
  [Route("mvc/odata/C4G/Pessoas")]
  public partial class PessoasController : ODataController
  {
    private Data.C4GContext context;

    public PessoasController(Data.C4GContext context)
    {
      this.context = context;
    }
    // GET /odata/C4G/Pessoas
    [EnableQuery(MaxExpansionDepth=10,MaxAnyAllExpressionDepth=10,MaxNodeCount=1000)]
    [HttpGet]
    public IEnumerable<Models.C4G.Pessoa> GetPessoas()
    {
      var items = this.context.Pessoas.AsQueryable<Models.C4G.Pessoa>();
      this.OnPessoasRead(ref items);

      return items;
    }

    partial void OnPessoasRead(ref IQueryable<Models.C4G.Pessoa> items);

    [EnableQuery(MaxExpansionDepth=10,MaxAnyAllExpressionDepth=10,MaxNodeCount=1000)]
    [HttpGet("{id_Pessoa}")]
    public SingleResult<Pessoa> GetPessoa(int key)
    {
        var items = this.context.Pessoas.Where(i=>i.id_Pessoa == key);
        this.OnPessoasGet(ref items);

        return SingleResult.Create(items);
    }

    partial void OnPessoasGet(ref IQueryable<Models.C4G.Pessoa> items);

    partial void OnPessoaDeleted(Models.C4G.Pessoa item);

    [HttpDelete("{id_Pessoa}")]
    public IActionResult DeletePessoa(int key)
    {
        try
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }


            var item = this.context.Pessoas
                .Where(i => i.id_Pessoa == key)
                .Include(i => i.Pedes)
                .Include(i => i.PertenceUis)
                .FirstOrDefault();

            if (item == null)
            {
                ModelState.AddModelError("", "Item no longer available");
                return BadRequest(ModelState);
            }

            this.OnPessoaDeleted(item);
            this.context.Pessoas.Remove(item);
            this.context.SaveChanges();

            return new NoContentResult();
        }
        catch(Exception ex)
        {
            ModelState.AddModelError("", ex.Message);
            return BadRequest(ModelState);
        }
    }

    partial void OnPessoaUpdated(Models.C4G.Pessoa item);

    [HttpPut("{id_Pessoa}")]
    [EnableQuery(MaxExpansionDepth=10,MaxAnyAllExpressionDepth=10,MaxNodeCount=1000)]
    public IActionResult PutPessoa(int key, [FromBody]Models.C4G.Pessoa newItem)
    {
        try
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (newItem == null || (newItem.id_Pessoa != key))
            {
                return BadRequest();
            }

            this.OnPessoaUpdated(newItem);
            this.context.Pessoas.Update(newItem);
            this.context.SaveChanges();

            var itemToReturn = this.context.Pessoas.Where(i => i.id_Pessoa == key);
            Request.QueryString = Request.QueryString.Add("$expand", "Servico,Instituicao,Gt");
            return new ObjectResult(SingleResult.Create(itemToReturn));
        }
        catch(Exception ex)
        {
            ModelState.AddModelError("", ex.Message);
            return BadRequest(ModelState);
        }
    }

    [HttpPatch("{id_Pessoa}")]
    [EnableQuery(MaxExpansionDepth=10,MaxAnyAllExpressionDepth=10,MaxNodeCount=1000)]
    public IActionResult PatchPessoa(int key, [FromBody]Delta<Models.C4G.Pessoa> patch)
    {
        try
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var item = this.context.Pessoas.Where(i => i.id_Pessoa == key).FirstOrDefault();

            if (item == null)
            {
                ModelState.AddModelError("", "Item no longer available");
                return BadRequest(ModelState);
            }

            patch.Patch(item);

            this.OnPessoaUpdated(item);
            this.context.Pessoas.Update(item);
            this.context.SaveChanges();

            var itemToReturn = this.context.Pessoas.Where(i => i.id_Pessoa == key);
            Request.QueryString = Request.QueryString.Add("$expand", "Servico,Instituicao,Gt");
            return new ObjectResult(SingleResult.Create(itemToReturn));
        }
        catch(Exception ex)
        {
            ModelState.AddModelError("", ex.Message);
            return BadRequest(ModelState);
        }
    }

    partial void OnPessoaCreated(Models.C4G.Pessoa item);

    [HttpPost]
    [EnableQuery(MaxExpansionDepth=10,MaxAnyAllExpressionDepth=10,MaxNodeCount=1000)]
    public IActionResult Post([FromBody] Models.C4G.Pessoa item)
    {
        try
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (item == null)
            {
                return BadRequest();
            }

            this.OnPessoaCreated(item);
            this.context.Pessoas.Add(item);
            this.context.SaveChanges();

            var key = item.id_Pessoa;

            var itemToReturn = this.context.Pessoas.Where(i => i.id_Pessoa == key);

            Request.QueryString = Request.QueryString.Add("$expand", "Servico,Instituicao,Gt");

            return new ObjectResult(SingleResult.Create(itemToReturn))
            {
                StatusCode = 201
            };
        }
        catch(Exception ex)
        {
            ModelState.AddModelError("", ex.Message);
            return BadRequest(ModelState);
        }
    }
  }
}
