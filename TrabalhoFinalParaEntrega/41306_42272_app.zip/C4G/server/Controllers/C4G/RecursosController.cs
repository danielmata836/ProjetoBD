using System;
using System.Net;
using System.Data;
using System.Linq;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNet.OData;
using Microsoft.AspNet.OData.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.AspNet.OData.Query;



namespace C4G.Controllers.C4G
{
  using Models;
  using Data;
  using Models.C4G;

  [ODataRoutePrefix("odata/C4G/Recursos")]
  [Route("mvc/odata/C4G/Recursos")]
  public partial class RecursosController : ODataController
  {
    private Data.C4GContext context;

    public RecursosController(Data.C4GContext context)
    {
      this.context = context;
    }
    // GET /odata/C4G/Recursos
    [EnableQuery(MaxExpansionDepth=10,MaxAnyAllExpressionDepth=10,MaxNodeCount=1000)]
    [HttpGet]
    public IEnumerable<Models.C4G.Recurso> GetRecursos()
    {
      var items = this.context.Recursos.AsQueryable<Models.C4G.Recurso>();
      this.OnRecursosRead(ref items);

      return items;
    }

    partial void OnRecursosRead(ref IQueryable<Models.C4G.Recurso> items);

    [EnableQuery(MaxExpansionDepth=10,MaxAnyAllExpressionDepth=10,MaxNodeCount=1000)]
    [HttpGet("{index_Recurso}")]
    public SingleResult<Recurso> GetRecurso(int key)
    {
        var items = this.context.Recursos.Where(i=>i.index_Recurso == key);
        this.OnRecursosGet(ref items);

        return SingleResult.Create(items);
    }

    partial void OnRecursosGet(ref IQueryable<Models.C4G.Recurso> items);

    partial void OnRecursoDeleted(Models.C4G.Recurso item);

    [HttpDelete("{index_Recurso}")]
    public IActionResult DeleteRecurso(int key)
    {
        try
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }


            var item = this.context.Recursos
                .Where(i => i.index_Recurso == key)
                .Include(i => i.Produtos)
                .Include(i => i.Formacaos)
                .Include(i => i.Equipamentos)
                .Include(i => i.EstaAtribuidos)
                .FirstOrDefault();

            if (item == null)
            {
                ModelState.AddModelError("", "Item no longer available");
                return BadRequest(ModelState);
            }

            this.OnRecursoDeleted(item);
            this.context.Recursos.Remove(item);
            this.context.SaveChanges();

            return new NoContentResult();
        }
        catch(Exception ex)
        {
            ModelState.AddModelError("", ex.Message);
            return BadRequest(ModelState);
        }
    }

    partial void OnRecursoUpdated(Models.C4G.Recurso item);

    [HttpPut("{index_Recurso}")]
    [EnableQuery(MaxExpansionDepth=10,MaxAnyAllExpressionDepth=10,MaxNodeCount=1000)]
    public IActionResult PutRecurso(int key, [FromBody]Models.C4G.Recurso newItem)
    {
        try
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (newItem == null || (newItem.index_Recurso != key))
            {
                return BadRequest();
            }

            this.OnRecursoUpdated(newItem);
            this.context.Recursos.Update(newItem);
            this.context.SaveChanges();

            var itemToReturn = this.context.Recursos.Where(i => i.index_Recurso == key);
            return new ObjectResult(SingleResult.Create(itemToReturn));
        }
        catch(Exception ex)
        {
            ModelState.AddModelError("", ex.Message);
            return BadRequest(ModelState);
        }
    }

    [HttpPatch("{index_Recurso}")]
    [EnableQuery(MaxExpansionDepth=10,MaxAnyAllExpressionDepth=10,MaxNodeCount=1000)]
    public IActionResult PatchRecurso(int key, [FromBody]Delta<Models.C4G.Recurso> patch)
    {
        try
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var item = this.context.Recursos.Where(i => i.index_Recurso == key).FirstOrDefault();

            if (item == null)
            {
                ModelState.AddModelError("", "Item no longer available");
                return BadRequest(ModelState);
            }

            patch.Patch(item);

            this.OnRecursoUpdated(item);
            this.context.Recursos.Update(item);
            this.context.SaveChanges();

            var itemToReturn = this.context.Recursos.Where(i => i.index_Recurso == key);
            return new ObjectResult(SingleResult.Create(itemToReturn));
        }
        catch(Exception ex)
        {
            ModelState.AddModelError("", ex.Message);
            return BadRequest(ModelState);
        }
    }

    partial void OnRecursoCreated(Models.C4G.Recurso item);

    [HttpPost]
    [EnableQuery(MaxExpansionDepth=10,MaxAnyAllExpressionDepth=10,MaxNodeCount=1000)]
    public IActionResult Post([FromBody] Models.C4G.Recurso item)
    {
        try
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (item == null)
            {
                return BadRequest();
            }

            this.OnRecursoCreated(item);
            this.context.Recursos.Add(item);
            this.context.SaveChanges();

            return Created($"odata/C4G/Recursos/{item.index_Recurso}", item);
        }
        catch(Exception ex)
        {
            ModelState.AddModelError("", ex.Message);
            return BadRequest(ModelState);
        }
    }
  }
}
