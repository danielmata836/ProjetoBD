using System;
using System.Net;
using System.Data;
using System.Linq;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNet.OData;
using Microsoft.AspNet.OData.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.AspNet.OData.Query;



namespace C4G.Controllers.C4G
{
  using Models;
  using Data;
  using Models.C4G;

  [ODataRoutePrefix("odata/C4G/Servicos")]
  [Route("mvc/odata/C4G/Servicos")]
  public partial class ServicosController : ODataController
  {
    private Data.C4GContext context;

    public ServicosController(Data.C4GContext context)
    {
      this.context = context;
    }
    // GET /odata/C4G/Servicos
    [EnableQuery(MaxExpansionDepth=10,MaxAnyAllExpressionDepth=10,MaxNodeCount=1000)]
    [HttpGet]
    public IEnumerable<Models.C4G.Servico> GetServicos()
    {
      var items = this.context.Servicos.AsQueryable<Models.C4G.Servico>();
      this.OnServicosRead(ref items);

      return items;
    }

    partial void OnServicosRead(ref IQueryable<Models.C4G.Servico> items);

    [EnableQuery(MaxExpansionDepth=10,MaxAnyAllExpressionDepth=10,MaxNodeCount=1000)]
    [HttpGet("{index_servicos}")]
    public SingleResult<Servico> GetServico(int key)
    {
        var items = this.context.Servicos.Where(i=>i.index_servicos == key);
        this.OnServicosGet(ref items);

        return SingleResult.Create(items);
    }

    partial void OnServicosGet(ref IQueryable<Models.C4G.Servico> items);

    partial void OnServicoDeleted(Models.C4G.Servico item);

    [HttpDelete("{index_servicos}")]
    public IActionResult DeleteServico(int key)
    {
        try
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }


            var item = this.context.Servicos
                .Where(i => i.index_servicos == key)
                .Include(i => i.EstaAtribuidos)
                .Include(i => i.Pessoas)
                .Include(i => i.Pedes)
                .FirstOrDefault();

            if (item == null)
            {
                ModelState.AddModelError("", "Item no longer available");
                return BadRequest(ModelState);
            }

            this.OnServicoDeleted(item);
            this.context.Servicos.Remove(item);
            this.context.SaveChanges();

            return new NoContentResult();
        }
        catch(Exception ex)
        {
            ModelState.AddModelError("", ex.Message);
            return BadRequest(ModelState);
        }
    }

    partial void OnServicoUpdated(Models.C4G.Servico item);

    [HttpPut("{index_servicos}")]
    [EnableQuery(MaxExpansionDepth=10,MaxAnyAllExpressionDepth=10,MaxNodeCount=1000)]
    public IActionResult PutServico(int key, [FromBody]Models.C4G.Servico newItem)
    {
        try
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (newItem == null || (newItem.index_servicos != key))
            {
                return BadRequest();
            }

            this.OnServicoUpdated(newItem);
            this.context.Servicos.Update(newItem);
            this.context.SaveChanges();

            var itemToReturn = this.context.Servicos.Where(i => i.index_servicos == key);
            Request.QueryString = Request.QueryString.Add("$expand", "Gt");
            return new ObjectResult(SingleResult.Create(itemToReturn));
        }
        catch(Exception ex)
        {
            ModelState.AddModelError("", ex.Message);
            return BadRequest(ModelState);
        }
    }

    [HttpPatch("{index_servicos}")]
    [EnableQuery(MaxExpansionDepth=10,MaxAnyAllExpressionDepth=10,MaxNodeCount=1000)]
    public IActionResult PatchServico(int key, [FromBody]Delta<Models.C4G.Servico> patch)
    {
        try
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var item = this.context.Servicos.Where(i => i.index_servicos == key).FirstOrDefault();

            if (item == null)
            {
                ModelState.AddModelError("", "Item no longer available");
                return BadRequest(ModelState);
            }

            patch.Patch(item);

            this.OnServicoUpdated(item);
            this.context.Servicos.Update(item);
            this.context.SaveChanges();

            var itemToReturn = this.context.Servicos.Where(i => i.index_servicos == key);
            Request.QueryString = Request.QueryString.Add("$expand", "Gt");
            return new ObjectResult(SingleResult.Create(itemToReturn));
        }
        catch(Exception ex)
        {
            ModelState.AddModelError("", ex.Message);
            return BadRequest(ModelState);
        }
    }

    partial void OnServicoCreated(Models.C4G.Servico item);

    [HttpPost]
    [EnableQuery(MaxExpansionDepth=10,MaxAnyAllExpressionDepth=10,MaxNodeCount=1000)]
    public IActionResult Post([FromBody] Models.C4G.Servico item)
    {
        try
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (item == null)
            {
                return BadRequest();
            }

            this.OnServicoCreated(item);
            this.context.Servicos.Add(item);
            this.context.SaveChanges();

            var key = item.index_servicos;

            var itemToReturn = this.context.Servicos.Where(i => i.index_servicos == key);

            Request.QueryString = Request.QueryString.Add("$expand", "Gt");

            return new ObjectResult(SingleResult.Create(itemToReturn))
            {
                StatusCode = 201
            };
        }
        catch(Exception ex)
        {
            ModelState.AddModelError("", ex.Message);
            return BadRequest(ModelState);
        }
    }
  }
}
