using System;
using Microsoft.AspNetCore.Mvc;

namespace C4G.Controllers
{
    public partial class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
