using System.Reflection;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

using C4G.Models.C4G;

namespace C4G.Data
{
    public partial class C4GContext : Microsoft.EntityFrameworkCore.DbContext
    {
        private readonly IHttpContextAccessor httpAccessor;

        public C4GContext(IHttpContextAccessor httpAccessor, DbContextOptions<C4GContext> options):base(options)
        {
            this.httpAccessor = httpAccessor;
        }

        public C4GContext(IHttpContextAccessor httpAccessor)
        {
            this.httpAccessor = httpAccessor;
        }

        partial void OnModelBuilding(ModelBuilder builder);

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<C4G.Models.C4G.EstaAtribuido>().HasKey(table => new {
              table.index_Recurso, table.index_servicos
            });
            builder.Entity<C4G.Models.C4G.Pede>().HasKey(table => new {
              table.id_Pessoa, table.index_servicos
            });
            builder.Entity<C4G.Models.C4G.PertenceUi>().HasKey(table => new {
              table.id_UI, table.id_Pessoa
            });
            builder.Entity<C4G.Models.C4G.Pertencer>().HasKey(table => new {
              table.Num_Inst, table.no_regis_produto
            });
            builder.Entity<C4G.Models.C4G.Equipamento>()
                  .HasOne(i => i.Recurso)
                  .WithMany(i => i.Equipamentos)
                  .HasForeignKey(i => i.index_Recurso)
                  .HasPrincipalKey(i => i.index_Recurso);
            builder.Entity<C4G.Models.C4G.EstaAtribuido>()
                  .HasOne(i => i.Recurso)
                  .WithMany(i => i.EstaAtribuidos)
                  .HasForeignKey(i => i.index_Recurso)
                  .HasPrincipalKey(i => i.index_Recurso);
            builder.Entity<C4G.Models.C4G.EstaAtribuido>()
                  .HasOne(i => i.Servico)
                  .WithMany(i => i.EstaAtribuidos)
                  .HasForeignKey(i => i.index_servicos)
                  .HasPrincipalKey(i => i.index_servicos);
            builder.Entity<C4G.Models.C4G.Formacao>()
                  .HasOne(i => i.Recurso)
                  .WithMany(i => i.Formacaos)
                  .HasForeignKey(i => i.index_Recurso)
                  .HasPrincipalKey(i => i.index_Recurso);
            builder.Entity<C4G.Models.C4G.Pede>()
                  .HasOne(i => i.Pessoa)
                  .WithMany(i => i.Pedes)
                  .HasForeignKey(i => i.id_Pessoa)
                  .HasPrincipalKey(i => i.id_Pessoa);
            builder.Entity<C4G.Models.C4G.Pede>()
                  .HasOne(i => i.Servico)
                  .WithMany(i => i.Pedes)
                  .HasForeignKey(i => i.index_servicos)
                  .HasPrincipalKey(i => i.index_servicos);
            builder.Entity<C4G.Models.C4G.PertenceUi>()
                  .HasOne(i => i.Ui)
                  .WithMany(i => i.PertenceUis)
                  .HasForeignKey(i => i.id_UI)
                  .HasPrincipalKey(i => i.id_UI);
            builder.Entity<C4G.Models.C4G.PertenceUi>()
                  .HasOne(i => i.Pessoa)
                  .WithMany(i => i.PertenceUis)
                  .HasForeignKey(i => i.id_Pessoa)
                  .HasPrincipalKey(i => i.id_Pessoa);
            builder.Entity<C4G.Models.C4G.Pertencer>()
                  .HasOne(i => i.Instituicao)
                  .WithMany(i => i.Pertencers)
                  .HasForeignKey(i => i.Num_Inst)
                  .HasPrincipalKey(i => i.Num_Inst);
            builder.Entity<C4G.Models.C4G.Pertencer>()
                  .HasOne(i => i.Equipamento)
                  .WithMany(i => i.Pertencers)
                  .HasForeignKey(i => i.no_regis_produto)
                  .HasPrincipalKey(i => i.no_regis_produto);
            builder.Entity<C4G.Models.C4G.Pessoa>()
                  .HasOne(i => i.Servico)
                  .WithMany(i => i.Pessoas)
                  .HasForeignKey(i => i.index_servicos)
                  .HasPrincipalKey(i => i.index_servicos);
            builder.Entity<C4G.Models.C4G.Pessoa>()
                  .HasOne(i => i.Instituicao)
                  .WithMany(i => i.Pessoas)
                  .HasForeignKey(i => i.Num_Inst)
                  .HasPrincipalKey(i => i.Num_Inst);
            builder.Entity<C4G.Models.C4G.Pessoa>()
                  .HasOne(i => i.Gt)
                  .WithMany(i => i.Pessoas)
                  .HasForeignKey(i => i.id_GT)
                  .HasPrincipalKey(i => i.id_GT);
            builder.Entity<C4G.Models.C4G.Produto>()
                  .HasOne(i => i.Recurso)
                  .WithMany(i => i.Produtos)
                  .HasForeignKey(i => i.index_Recurso)
                  .HasPrincipalKey(i => i.index_Recurso);
            builder.Entity<C4G.Models.C4G.Servico>()
                  .HasOne(i => i.Gt)
                  .WithMany(i => i.Servicos)
                  .HasForeignKey(i => i.id_GT)
                  .HasPrincipalKey(i => i.id_GT);


            builder.Entity<C4G.Models.C4G.Equipamento>()
                  .Property(p => p.garantia)
                  .HasColumnType("date");

            builder.Entity<C4G.Models.C4G.Servico>()
                  .Property(p => p.data_inicio)
                  .HasColumnType("date");

            builder.Entity<C4G.Models.C4G.Servico>()
                  .Property(p => p.data_fim)
                  .HasColumnType("date");

            this.OnModelBuilding(builder);
        }


        public DbSet<C4G.Models.C4G.Equipamento> Equipamentos
        {
          get;
          set;
        }

        public DbSet<C4G.Models.C4G.EstaAtribuido> EstaAtribuidos
        {
          get;
          set;
        }

        public DbSet<C4G.Models.C4G.Formacao> Formacaos
        {
          get;
          set;
        }

        public DbSet<C4G.Models.C4G.Gt> Gts
        {
          get;
          set;
        }

        public DbSet<C4G.Models.C4G.Instituicao> Instituicaos
        {
          get;
          set;
        }

        public DbSet<C4G.Models.C4G.Pede> Pedes
        {
          get;
          set;
        }

        public DbSet<C4G.Models.C4G.PertenceUi> PertenceUis
        {
          get;
          set;
        }

        public DbSet<C4G.Models.C4G.Pertencer> Pertencers
        {
          get;
          set;
        }

        public DbSet<C4G.Models.C4G.Pessoa> Pessoas
        {
          get;
          set;
        }

        public DbSet<C4G.Models.C4G.Produto> Produtos
        {
          get;
          set;
        }

        public DbSet<C4G.Models.C4G.Recurso> Recursos
        {
          get;
          set;
        }

        public DbSet<C4G.Models.C4G.Servico> Servicos
        {
          get;
          set;
        }

        public DbSet<C4G.Models.C4G.Ui> Uis
        {
          get;
          set;
        }
    }
}
